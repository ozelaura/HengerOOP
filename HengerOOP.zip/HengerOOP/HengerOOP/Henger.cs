﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HengerOOP
{
    public class Henger
    {
        private int magassag;
        private int sugar;
        private int szuletesSzamlalo;

        public int GetMagassag { get => magassag; }
        public int GetSugar { get => sugar; }
        public int SzuletesSzamlalo { get => szuletesSzamlalo; }

       

        public void Terfogat()
        {
            return Math.Round(sugar * sugar * Math.PI * magassag, 2);
        }

        public void ToString()
        {
            return $"Jellemzők >> térfogat: {this.Terfogat()}; sugár: {this.sugar}; magasság: {this.magassag}";
        }
    }
}
