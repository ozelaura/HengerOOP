﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HengerOOP
{
    public class Cso:Henger
    {
        double falVastagsag;

        public Cso(double magassag, double sugar, double falVastagsag) : base(magassag, sugar)
        {
            this.falVastagsag = falVastagsag;
        }

        public Cso(double magassag, double sugar) : base(magassag, sugar)
        {
            this.falVastagsag = 1;
        }


        public int FalVastagsag { get => (int)falVastagsag; }


        public void Terfogat()
        {
            double terfogat1 = Math.Round(Math.PI * base.GetSugar * base.GetMagassag, 2);
            double terfogat2 = Math.Round(Math.PI * Math.Pow(base.GetSugar - this.falVastagsag, 2) * base.GetMagassag , 2);

        }

        public string ToString()
        {
            return $"Jellemzők >> térfogat: {this.Terfogat()}; sugár: {base.GetSugar}; ,agasság: {base.GetMagassag}; falvastagság: {this.falVastagsag}";
        }
    }
}
